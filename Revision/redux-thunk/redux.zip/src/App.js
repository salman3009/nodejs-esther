import './App.css';
import { useDispatch, useSelector} from 'react-redux'
import { increment,decrement,incrementByAmount } from './counterSlice';

function App() {

  const email = useSelector((state)=>state.counter.email);
  const value = useSelector((state)=>state.counter.value);
  const dispatch = useDispatch();
  return (
    <div className="App">
      <h1>{email}</h1>
      <h1>{value}</h1>
      <button onClick={()=>dispatch(increment({value:2,email:"suresh@gmail.com"}))}>increment</button>
      <button onClick={()=>dispatch(decrement())}>decrement</button>
      <button onClick={()=>dispatch(incrementByAmount(20))}>Default value</button>
    </div>
  );
}

export default App;
